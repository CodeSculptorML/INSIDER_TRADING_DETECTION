from flask import Flask, render_template
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import base64

app = Flask(__name__)

# Function to encode image file as base64
def encode_image(image_path):
    with open(image_path, "rb") as img_file:
        encoded_string = base64.b64encode(img_file.read()).decode()
    return encoded_string

'''def generate_pie_chart(accuracy):
    labels = ['Correct', 'Incorrect']
    sizes = [accuracy, 100 - accuracy]
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
    plt.title('Model Accuracy')
    pie_chart_path = f"insider trading/static/pie_chart.png"
    plt.savefig(pie_chart_path)
    plt.close()
    return pie_chart_path'''



def generate_company_graph(company):
    # Load data and filter for the specific company
    df = pd.read_csv('insider trading\sorted_insider_trading_data.csv')  # Replace 'your_data.csv' with your actual dataset file
    company_data = df[df['SYMBOL \n'] == company]

    # Plot buy-sell graph
    plt.figure(figsize=(10, 6))
    plt.plot(company_data['DATE OF ALLOTMENT/ACQUISITION FROM \n'], company_data['ACQUISITION/DISPOSAL TRANSACTION TYPE \n'], marker='o')
    plt.title(f"Buy-Sell Graph for {company}")
    plt.xlabel('Date')
    plt.ylabel('Transaction Type')
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()

    # Save the graph
    plt.savefig(f"insider trading/static/{company}_graph.png")  # Adjust the path as needed
    plt.close()

@app.route('/')
def index():
    # Load data and perform necessary operations
    # Assuming you have already processed the data and generated the graphs and accuracy
    # Replace these with your actual data and logic
    suspected_companies = ["M&M", "MPHASIS", "COFORGE"]
    accuracy = 73  # Example accuracy

    # Generate and save pie chart
    #pie_chart_path = generate_pie_chart(accuracy)

    # Generate and save graphs for suspected companies
    for company in suspected_companies:
        generate_company_graph(company)

    # Dictionary to store image data for each suspected company
    graphs = {}

    # Load and encode images for suspected companies
    for company in suspected_companies:
        #image_path = f"insider trading\static\{company}_graph.png"  # Adjust the path to your saved graphs
        #insider trading\static\M&M_graph.png
        image_path = f"insider trading/static/{company}_graph.png"

        encoded_image = encode_image(image_path)
        graphs[company] = encoded_image

    return render_template('index.html', suspected_companies=suspected_companies, graphs=graphs,accuracy=accuracy)

if __name__ == '__main__':
    app.run(debug=True)
